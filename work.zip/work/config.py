
import psycopg2
DB_Host='Localhost'
DB_Name='test1'
DB_User='postgres'
DB_pass='12345'

#conn = psycopg2.connect(database="test1", password = "12345", host = "localhost")
conn = psycopg2.connect(dbname=DB_Name , user=DB_User, password=DB_pass,host=DB_Host)
#print("Opened database successfully")
cur = conn.cursor()

cur.execute("SELECT * FROM shows")
# commit, so it does the executions on the db and persists in the db
conn.commit()

conn.close()
cur.close()








